If don't want to sync this maven repository from product, just let this folder to be existed (even empty folder).
